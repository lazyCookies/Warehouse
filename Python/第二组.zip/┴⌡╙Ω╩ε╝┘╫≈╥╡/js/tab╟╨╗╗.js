var top1 = document.querySelector('.top')
var t = document.querySelector('.text1')
var click = document.querySelector('.click')
var click2 = document.querySelector('.click2')
var box6 = document.querySelector('.box3')
var box1 = document.querySelector('.box1')
var box66 = document.querySelector('.box33')
var box11 = document.querySelector('.box11')
var mi = document.querySelector('.mi')
var mi2 = document.querySelector('.mii')
var mi3 = document.querySelector('.mi3')
var top4= document.querySelector('.top4')
var l= document.querySelector('.l')
t.onfocus=function(){
	top1.className='topp'
}
t.onblur=function(){
	top1.className='top'
}
click.onclick=function(){
	box6.style='display:inlne;'
	box1.style='display:none;'
	click.style='display：none;'
	click2.style='display:inlne;'
}
click2.onclick=function(){
	box6.style='display:none;'
	box1.style='display:inlne;'
	click.style='display：inlne;'
	click2.style='display:none;'
}
mi.onclick = function(){
	top4.className='top44'
	l.className='ll'
	mi.className='mi1'
	mi2.style='display:inlne;'
	mi3.style='display:inlne;'
}
mi2.onclick = function(){
	top4.className='top4'
	l.className='l'
	mi.className='mi'
	mi2.style='display:none;'
	mi3.style='display:none;'
}


//var ver = document.querySelector('.ver')
//var tel = document.querySelector('.tel')
//var  telRag = /^1[3456789]\d{9}&/
//ver.onclick = function  () {
//	if( telRag.test(tel.value)){
//		
//	}else{
//		alert('输入有无')
//	}
//}