function getStyle(element, attr) { // 获取对象内的任一css属性值的函数, element == DOM对象， attr == 属性名
	if(element.currentStyle) { // IE浏览器会识别
		return element.currentStyle[attr]; // 返回IE中获取属性的值
	} else { // 其它浏览器
		return getComputedStyle(element, false)[attr];
	}
}

function goTop() { // 返回顶部，先快后慢的动画
	var timer = setInterval(function() {
		var scrollTop = document.documentElement.scrollTop || window.pageYOffset || document.body.scrollTop
		var speed = scrollTop / 7; // 7200/4 先快后慢动画
		if(document.body.scrollTop != 0) {
			document.body.scrollTop -= speed;
		} else {
			document.documentElement.scrollTop -= speed;
		}
		if(scrollTop == 0) {
			clearInterval(timer);
		}
	}, 16.7)
}