var span = document.querySelectorAll('.li-bg span')
var libg = document.querySelectorAll('.li-bg')
var kuang = document.querySelector('.kuang img')
var top3 = document.querySelectorAll('.top3-bottom-c1')
var top33 =document.querySelector('.toop')
var img1 = document.querySelector('.top3-img')
var box = document.querySelector('.box')
var mei = document.querySelector('.mei')
var qiandao = document.querySelector('.qiandao')
var xia = document.querySelector('.xia')
var app = document.querySelector('.app')
var i1= document.querySelector('.i1')
var i2= document.querySelector('.i2')
var i3= document.querySelector('.i3')
var i4= document.querySelector('.i4')
var i5= document.querySelector('.i5')
var i6= document.querySelector('.i6')
var i7= document.querySelector('.i7')
var i8= document.querySelector('.i8')

libg[0].onmouseenter=function  () {
	span[0].className='iconfont icon-caret-up'
}
libg[1].onmouseenter=function  () {
	span[1].className='iconfont icon-caret-up'
}
libg[2].onmouseenter=function  () {
	span[2].className='iconfont icon-caret-up'
}
libg[3].onmouseenter=function  () {
	span[3].className='iconfont icon-caret-up'
}
libg[4].onmouseenter=function  () {
	span[4].className='iconfont icon-caret-up'
}
libg[0].onmouseleave=function  () {
	span[0].className='iconfont icon-xiajiantou'
}
libg[1].onmouseleave=function  () {
	span[1].className='iconfont icon-xiajiantou'
}
libg[2].onmouseleave=function  () {
	span[2].className='iconfont icon-xiajiantou'
}
libg[3].onmouseleave=function  () {
	span[3].className='iconfont icon-xiajiantou'
}
libg[4].onmouseleave=function  () {
	span[4].className='iconfont icon-xiajiantou'
}
//top结束
kuang.onmouseenter=function () {
	kuang.src='../img/img11.png'
}
kuang.onmouseleave=function () {
	kuang.src='../img/img10.png'
}
top3[0].onmouseenter = function(){
	top3[0].style='background-color: #FFFFFF; color: #FF2D40;'
	img1.innerHTML='<img src="../img/img13.png"/>'
}
top3[0].onmouseleave = function(){
	top3[0].style='background-color: #FF2D40; color: #FFF'
	img1.innerHTML='<p class="top3-img"></p>'
}
top3[1].onmouseenter = function(){
	top3[1].style='background-color: #FFFFFF; color: #FF2D40;'
	img1.innerHTML='<img src="../img/img14.png"/>'
}
top3[1].onmouseleave = function(){
	top3[1].style='background-color: #FF2D40; color: #FFF'
	img1.innerHTML='<p class="top3-img"></p>'
}
top3[2].onmouseenter = function(){
	top3[2].style='background-color: #FFFFFF; color: #FF2D40;'
	img1.innerHTML='<img src="../img/img15.png"/>'
}
top3[2].onmouseleave = function(){
	top3[2].style='background-color: #FF2D40; color: #FFF'
	img1.innerHTML='<p class="top3-img"></p>'
}
top3[3].onmouseenter = function(){
	top3[3].style='background-color: #FFFFFF; color: #FF2D40;'
	img1.innerHTML='<img src="../img/img16.png"/>'
}
top3[3].onmouseleave = function(){
	top3[3].style='background-color: #FF2D40; color: #FFF'
	img1.innerHTML='<p class="top3-img"></p>'
}
top3[4].onmouseenter = function(){
	top3[4].style='background-color: #FFFFFF; color: #FF2D40;'
	img1.innerHTML='<img src="../img/img17.png"/>'
}
top3[4].onmouseleave = function(){
	top3[4].style='background-color: #FF2D40; color: #FFF'
	img.innerHTML='<p class="top3-img"></p>'
}
top3[5].onmouseenter = function(){
	top3[5].style='background-color: #FFFFFF; color: #FF2D40;'
	img1.innerHTML='<img src="../img/img18.png"/>'
}
top3[5].onmouseleave = function(){
	top3[5].style='background-color: #FF2D40; color: #FFF'
	img1.innerHTML='<p class="top3-img"></p>'
}
top3[6].onmouseenter = function(){
	top3[6].style='background-color: #FFFFFF; color: #FF2D40;'
	img1.innerHTML='<img src="../img/img19.png"/>'
}
top3[6].onmouseleave = function(){
	top3[6].style='background-color: #FF2D40; color: #FFF'
	img1.innerHTML='<p class="top3-img"></p>'
}
top3[7].onmouseenter = function(){
	top3[7].style='background-color: #FFFFFF; color: #FF2D40;'
	img1.innerHTML='<img src="../img/img20.png"/>'
}
top3[7].onmouseleave = function(){
	top3[7].style='background-color: #FF2D40; color: #FFF'
	img1.innerHTML='<p class="top3-img"></p>'
}
top3[8].onmouseenter = function(){
	top3[8].style='background-color: #FFFFFF; color: #FF2D40;'
	img1.innerHTML='<img src="../img/img21.png"/>'
}
top3[8].onmouseleave = function(){
	top3[8].style='background-color: #FF2D40; color: #FFF'
	img1.innerHTML='<p class="top3-img"></p>'
}
top3[9].onmouseenter = function(){
	top3[9].style='background-color: #FFFFFF; color: #FF2D40;'
	img1.innerHTML='<img src="../img/img22.png"/>'
}
top3[9].onmouseleave = function(){
	top3[9].style='background-color: #FF2D40; color: #FFF'
	img1.innerHTML='<p class="top3-img"></p>'
}
top3[10].onmouseenter = function(){
	top3[10].style='background-color: #FFFFFF; color: #FF2D40;'
	img1.innerHTML='<img src="../img/img23.png"/>'
}
top3[10].onmouseleave = function(){
	top3[10].style='background-color: #FF2D40; color: #FFF'
	img1.innerHTML='<p class="top3-img"></p>'
}
top3[11].onmouseenter = function(){
	top3[11].style='background-color: #FFFFFF; color: #FF2D40;'
	img1.innerHTML='<img src="../img/img24.png"/>'
}
top3[11].onmouseleave = function(){
	top3[11].style='background-color: #FF2D40; color: #FFF'
	img1.innerHTML='<p class="top3-img"></p>'
}
//top3-bottom结束
box.onclick = function  () {
				goTop()
			}
//返回顶部
qiandao.onmouseenter = function(){
	mei.innerHTML='<img src="../img/img27.png"class="q-img"/>'
}
qiandao.onmouseleave = function(){
	mei.innerHTML='<p class="mei"></p>'
}
app.onmouseenter = function(){
	xia.innerHTML='<img src="../img/img28.png"class="a-img"/>'
}
app.onmouseleave = function(){
	xia.innerHTML='<p class="xia"></p>'
}
//右边栏鼠标事件
i1.onmouseenter = function(){
	i1.innerHTML='<img src="../img/img41.png" class="i11"/>'
}
i1.onmouseleave = function(){
	i1.innerHTML='<img src="../img/img33.png" class="img"/><p class="p1">创造美丽生活的文化</p>'
}
i2.onmouseenter = function(){
	i2.innerHTML='<img src="../img/img42.png" class="i11"/>'
}
i2.onmouseleave = function(){
	i2.innerHTML='<img src="../img/img34.png" class="img"/><p class="p1">科学配方 优质原材料</p>'
}
i3.onmouseenter = function(){
	i3.innerHTML='<img src="../img/img43.png" class="i11"/>'
}
i3.onmouseleave = function(){
	i3.innerHTML='<img src="../img/img35.png" class="img"/><p class="p1">国际知名母婴用品品牌</p>'
}
i4.onmouseenter = function(){
	i4.innerHTML='<img src="../img/img44.png" class="i11"/>'
}
i4.onmouseleave = function(){
	i4.innerHTML='<img src="../img/img36.png" class="img"/><p class="p1">富含益生元GOS保护肠道健康</p>'
}
i5.onmouseenter = function(){
	i5.innerHTML='<img src="../img/img46.png" class="i11"/>'
}
i5.onmouseleave = function(){
	i5.innerHTML='<img src="../img/img37.png" class="img"/><p class="p1">法兰西的浪漫玫瑰</p>'
}
i6.onmouseenter = function(){
	i6.innerHTML='<img src="../img/img45.png" class="i11"/>'
}
i6.onmouseleave = function(){
	i6.innerHTML='<img src="../img/img38.png" class="img"/><p class="p1">妈妈之选大赏得主</p>'
}
i7.onmouseenter = function(){
	i7.innerHTML='<img src="../img/img47.png" class="i11"/>'
}
i7.onmouseleave = function(){
	i7.innerHTML='<img src="../img/img39.png" class="img"/><p class="p1">追求卓越的性能，安全和易用性</p>'
}
i8.onmouseenter = function(){
	i8.innerHTML='<img src="../img/img48.png" class="i11"/>'
}
i8.onmouseleave = function(){
	i8.innerHTML='<img src="../img/img40.png" class="img"/><p class="p1">合法合规的多用途预付费卡</p>'
}
//循环
var arr = [' ../img/img32.png', '../img/img76.png', '../img/img77.png'] 
var img = document.querySelector('.re-img')
var lis = document.querySelectorAll('.list li')
lis[0].style.background = 'red'
var index = 0 
function autoPlay() {
	index++
	if(index == 3) {
		index = 0
	}
	img.src = arr[index] 
	for(var i = 0; i < lis.length; i++) {
		lis[i].style.background = ''
	}
	lis[index].style.background = 'red' 
}
var timer1 = setInterval(autoPlay, 2500)
for(var i = 0; i < lis.length; i++) {
	lis[i].setAttribute('data-index', i) 
	lis[i].onmouseenter = function() { 
		clearInterval(timer1)
		index = this.getAttribute('data-index')
		console.log(index)
		img.src = arr[index] 
		for(var i = 0; i < lis.length; i++) {
			lis[i].style.background = ''
		} 
		lis[index].style.background = 'red' 
	}
	lis[i].onmouseleave = function() {
		timer1 = setInterval(autoPlay, 2000)
	}
}

